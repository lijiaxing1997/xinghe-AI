import asyncio
import os
import base64
import json

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from kokoro import KModel, KPipeline
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
import numpy as np
import soundfile as sf
import re
import uvicorn
import uuid

app = FastAPI()

origins = [
    "*",  # 输入自己前端项目的地址
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

REPO_ID = 'hexgrad/Kokoro-82M-v1.1-zh'
SAMPLE_RATE = 24000
N_ZEROS = 5000
JOIN_SENTENCES = True

VOICE = './kokora音色/zh_voices/zf_044.pt'

device = 'mps'

en_pipeline = KPipeline(lang_code='a', repo_id=REPO_ID, model=False)
def en_callable(text):
    if text == 'Kokoro':
        return 'kˈOkəɹO'
    elif text == 'Sol':
        return 'sˈOl'
    return next(en_pipeline(text)).phonemes

def speed_callable(len_ps):
    speed = 0.8
    if len_ps <= 83:
        speed = 1
    elif len_ps < 183:
        speed = 1 - (len_ps - 83) / 500
    return speed * 1.1

model = KModel(repo_id=REPO_ID).to(device).eval()
zh_pipeline = KPipeline(lang_code='z', repo_id=REPO_ID, model=model, en_callable=en_callable)

SENTENCE_END_PUNCTUATIONS = r"[。？！；\.\?\!\;]"

def preprocess_text(text):
    pattern = re.compile(r"[^\u4e00-\u9fa5a-zA-Z0-9,.\!?，。！？]")

    # 使用 sub() 方法替换掉所有不符合模式的字符
    cleaned_text = pattern.sub('', text)

    return cleaned_text

def gen_zh_voice(text:str):
    generator = zh_pipeline(text, voice=VOICE, speed=speed_callable)
    result = next(generator)
    wav = result.audio
    return wav


@app.websocket("/genVoice")
async def genVoice(websocket: WebSocket):
    await websocket.accept()
    print("WebSocket connection accepted.")
    received_buffer = ""
    seq_counter = 1
    try:
        while True:
            try:
                data = await websocket.receive_text()
                print(f"Received text: {data}")
                
                # Preprocess the text to handle special characters
                processed_data = preprocess_text(data)
                print(f"Preprocessed text: {processed_data}")
                
                received_buffer += processed_data
                raw_sentences = re.split(SENTENCE_END_PUNCTUATIONS, received_buffer)
                print(f"Split into {len(raw_sentences)} raw sentence(s)")
                processed_sentences = []
                if raw_sentences and not raw_sentences[-1]:
                    raw_sentences.pop()
                    received_buffer = ""
                elif raw_sentences:
                    received_buffer = raw_sentences.pop()
                else:
                    received_buffer = ""

                temp_sentence_buffer = ""
                for i, sentence in enumerate(raw_sentences):
                    sentence_stripped = sentence.strip()
                    if not sentence_stripped:
                        continue
                    
                    # Special handling for quotes - treat quotes as complete sentences
                    # even if they're short
                    has_quotes = re.search(r'[""\'\'""\']', sentence_stripped)
                    
                    if len(sentence_stripped) <= 5 and not has_quotes:
                        temp_sentence_buffer += sentence_stripped
                    else:
                        if temp_sentence_buffer:
                            processed_sentences.append(temp_sentence_buffer + sentence_stripped)
                            temp_sentence_buffer = ""
                        else:
                            processed_sentences.append(sentence_stripped)

                if temp_sentence_buffer:
                    processed_sentences.append(temp_sentence_buffer)

                for sentence in processed_sentences:
                    if sentence:  # 确保句子不为空
                        print(f"Processing sentence: '{sentence}'")
                        loop = asyncio.get_running_loop()
                        file_name = None
                        try:
                            audio_data = await loop.run_in_executor(None, gen_zh_voice, sentence)
                            file_name = f"{uuid.uuid4()}.wav"
                            sf.write(file_name, audio_data, SAMPLE_RATE)
                            
                            # Calculate audio duration
                            duration = len(audio_data) / SAMPLE_RATE
                            
                            # Read the audio file and convert to base64
                            with open(file_name, "rb") as f:
                                audio_bytes = f.read()
                                audio_base64 = base64.b64encode(audio_bytes).decode('utf-8')
                            
                            # Create JSON response
                            response = {
                                "seq": seq_counter,
                                "text": sentence,
                                "wav_base64": audio_base64,
                                "duration": f"{duration:.2f}"
                            }
                            
                            # Send JSON response
                            await websocket.send_json(response)
                            seq_counter += 1
                            
                            print(f"Sent audio data for sentence: '{sentence}'")
                        except WebSocketDisconnect:
                            print(f"Client disconnected during processing")
                            raise  # Re-raise to be caught by outer exception handler
                        except Exception as e:
                            print(f"Error generating or sending audio for '{sentence}': {e}")
                            try:
                                await websocket.send_text(f"Error: {e}")
                            except:
                                print("Could not send error message - client likely disconnected")
                                break
                        finally:
                            # Clean up temporary file even if an exception occurs
                            if file_name and os.path.exists(file_name):
                                os.remove(file_name)
            except WebSocketDisconnect:
                print("Client disconnected")
                break
    except WebSocketDisconnect:
        print("WebSocket disconnected")
    except Exception as e:
        print(f"Unexpected error in WebSocket handler: {e}")
    finally:
        print("WebSocket connection closed")

@app.websocket("/")
async def ws_test(websocket: WebSocket):
    await websocket.accept()
    await websocket.send_json({"message": "Hello, WebSocket!"})

@app.get("/")
async def root():
    return {"message": "Hello World"}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8021)