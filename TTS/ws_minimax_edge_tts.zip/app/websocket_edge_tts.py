import base64
import librosa
import soundfile as sf
from dotenv import load_dotenv
import os
from handle_text import prepare_tts_input_with_context
from tts_handler import generate_speech, get_models, get_voices, _generate_audio
from utils import getenv_bool, require_api_key, AUDIO_FORMAT_MIME_TYPES
from fastapi import FastAPI, WebSocket, WebSocketDisconnect,Request
from fastapi.middleware.cors import CORSMiddleware

import logging
import re
import asyncio
import uvicorn
import json
import requests


# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("tts_service.log")
    ]
)
logger = logging.getLogger("tts_service")



# 断句正则表达式
SENTENCE_END_PUNCTUATIONS = r"[。？！；\?\!\;\n]"

# 特殊命令
CMD_FLUSH = "__FLUSH__"  # 强制处理缓冲区中的所有文本
CMD_END = "__END__"      # 结束会话

load_dotenv()

API_KEY = os.getenv('API_KEY', 'your_api_key_here')
PORT = int(os.getenv('PORT', 5050))
DEFAULT_VOICE = os.getenv('DEFAULT_VOICE', 'en-US-AvaNeural')
DEFAULT_RESPONSE_FORMAT = os.getenv('DEFAULT_RESPONSE_FORMAT', 'wav')
DEFAULT_SPEED = float(os.getenv('DEFAULT_SPEED', 1.0))

REMOVE_FILTER = getenv_bool('REMOVE_FILTER', False)
EXPAND_API = getenv_bool('EXPAND_API', True)

app = FastAPI()

origins = [
    "*",  # 输入自己前端项目的地址
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 音频文件处理函数
def get_audio_duration(file_path):
    """安全获取音频文件时长，避免使用librosa直接读取整个文件"""
    try:
        # 使用soundfile读取音频文件信息，而不是加载整个文件
        info = sf.info(file_path)
        return info.duration
    except Exception as e:
        logger.error(f"无法获取音频时长: {e}")
        # 如果soundfile失败，尝试librosa但用低级API
        try:
            duration = librosa.get_duration(path=file_path)
            return duration
        except Exception as e2:
            logger.error(f"librosa也无法获取音频时长: {e2}")
            return 1.0  # 返回默认值


async def process_sentence(websocket, sentence, seq_counter, config):
    """处理单个句子并发送结果"""
    if not sentence.strip():
        return seq_counter

    logger.info(f"Processing sentence: '{sentence}'")
    loop = asyncio.get_running_loop()
    try:
        # 根据配置选择TTS处理函数
        if config.get("type") == "minimax":
            # 使用minimax TTS
            result = await loop.run_in_executor(
                None,
                minimax_text2voice,
                config.get("api_key", ""),
                config.get("group_id", ""),
                sentence,
                seq_counter,
                config.get("voice_id", "female-shaonv"),
                "happy",  # emotion参数，可以后续扩展
                config
            )
        else:
            # 使用默认的edge TTS
            result = await loop.run_in_executor(None, text2voice, sentence, seq_counter, config)

        # 发送结果给客户端
        await websocket.send_json(result)
        seq_counter += 1

        logger.info(f"Sent audio data for sentence: '{sentence}'")
    except Exception as e:
        logger.error(f"Error generating or sending audio for '{sentence}': {e}")
        try:
            await websocket.send_text(f"Error: {e}")
        except:
            logger.error("Could not send error message - client likely disconnected")
            raise

    return seq_counter


@app.websocket("/genVoice")
async def genVoice(websocket: WebSocket):
    await websocket.accept()
    logger.info("WebSocket connection accepted.")
    received_buffer = ""
    seq_counter = 1

    # 连接级别的配置存储
    connection_config = {
        "api_key": "",
        "group_id": "",
        "voice_id": DEFAULT_VOICE,
        "speed": DEFAULT_SPEED,
        "vol": 2,
        "type": "edge"  # 默认使用edge TTS
    }
    try:
        while True:
            try:
                # 接收数据（可能是文本或JSON）
                data = await websocket.receive_text()
                logger.info(f"Received data: {data}")
                
                # 检查是否是JSON格式的命令或配置
                try:
                    json_data = json.loads(data)
                    if isinstance(json_data, dict):
                        # 处理配置更新
                        if "api_key" in json_data or "group_id" in json_data or "voice_id" in json_data or "type" in json_data:
                            logger.info(f"Received configuration: {json_data}")
                            # 更新连接配置
                            for key in ["api_key", "group_id", "voice_id", "speed", "vol", "type"]:
                                if key in json_data:
                                    connection_config[key] = json_data[key]
                            logger.info(f"Updated connection config: {connection_config}")

                            # 发送配置确认消息给客户端（隐藏敏感信息）
                            safe_config = {k: v for k, v in connection_config.items() if k not in ["api_key", "group_id"]}
                            config_response = {
                                "type": "config_updated",
                                "status": "success",
                                "message": "Configuration updated successfully",
                                "config": safe_config
                            }
                            print("对客户端发送配置请求的返回:",config_response)
                            await websocket.send_json(config_response)
                            continue

                        # 处理特殊命令
                        if "command" in json_data:
                            command = json_data["command"]

                            if command == CMD_FLUSH and received_buffer:
                                logger.info(f"Received FLUSH command, processing remaining buffer: '{received_buffer}'")
                                seq_counter = await process_sentence(websocket, received_buffer, seq_counter, connection_config)
                                received_buffer = ""
                                continue
                            elif command == CMD_END:
                                logger.info("Received END command, closing connection")
                                if received_buffer:
                                    seq_counter = await process_sentence(websocket, received_buffer, seq_counter, connection_config)
                                await websocket.close()
                                break
                except (json.JSONDecodeError, TypeError):
                    # 不是JSON或不是预期的命令格式，当作普通文本处理
                    pass
                
                # 检查是否包含特殊命令字符串
                if data == CMD_FLUSH and received_buffer:
                    logger.info(f"Received FLUSH command, processing remaining buffer: '{received_buffer}'")
                    seq_counter = await process_sentence(websocket, received_buffer, seq_counter, connection_config)
                    received_buffer = ""
                    continue
                elif data == CMD_END:
                    logger.info("Received END command, closing connection")
                    if received_buffer:
                        seq_counter = await process_sentence(websocket, received_buffer, seq_counter, connection_config)
                    await websocket.close()
                    break
                
                # 将接收到的文本添加到缓冲区
                received_buffer += data
                
                # 按句子结束标点符号分割文本
                raw_sentences = re.split(f"({SENTENCE_END_PUNCTUATIONS})", received_buffer)
                logger.info(f"Split into {len(raw_sentences)} raw sentence parts")
                
                processed_sentences = []
                complete_buffer = ""
                
                # 重建完整句子（包含标点符号）
                i = 0
                while i < len(raw_sentences):
                    if i + 1 < len(raw_sentences) and re.match(SENTENCE_END_PUNCTUATIONS, raw_sentences[i+1]):
                        complete_sentence = raw_sentences[i] + raw_sentences[i+1]
                        processed_sentences.append(complete_sentence)
                        i += 2
                    else:
                        if i == len(raw_sentences) - 1:  # 最后一个元素，可能是不完整的句子
                            complete_buffer = raw_sentences[i]
                        else:
                            processed_sentences.append(raw_sentences[i])
                        i += 1
                
                # 更新缓冲区为可能的不完整句子
                received_buffer = complete_buffer
                
                # 处理短句合并
                final_sentences = []
                temp_sentence_buffer = ""
                
                for sentence in processed_sentences:
                    sentence_stripped = sentence.strip()
                    if not sentence_stripped:
                        continue
                    
                    # 特殊处理引号 - 即使很短也作为完整句子处理
                    has_quotes = re.search(r'[""\'\'""\']', sentence_stripped)
                    
                    if len(sentence_stripped) <= 5 and not has_quotes and not re.search(SENTENCE_END_PUNCTUATIONS, sentence_stripped):
                        temp_sentence_buffer += sentence_stripped
                    else:
                        if temp_sentence_buffer:
                            final_sentences.append(temp_sentence_buffer + sentence_stripped)
                            temp_sentence_buffer = ""
                        else:
                            final_sentences.append(sentence_stripped)
                
                # 处理每个完整句子
                for sentence in final_sentences:
                    seq_counter = await process_sentence(websocket, sentence, seq_counter, connection_config)
                    
            except WebSocketDisconnect:
                logger.info("Client disconnected")
                break
    except WebSocketDisconnect:
        logger.info("WebSocket disconnected")
    except Exception as e:
        logger.error(f"Unexpected error in WebSocket handler: {e}")
        # 尝试处理剩余的缓冲区内容
        if received_buffer:
            try:
                await process_sentence(websocket, received_buffer, seq_counter, connection_config)
            except:
                pass
    finally:
        logger.info("WebSocket connection closed")


@app.get("/")
async def root():
    return {"message": "Hello World"}


@app.websocket("/")
async def ws_test(websocket: WebSocket):
    await websocket.accept()
    await websocket.send_json({"message": "Hello, WebSocket!"})

def remove_special_tags(text):
    """
    移除文本中 <表情>...</表情> 和 <动作>...</动作> 这样的特殊标签及其内容。

    Args:
        text (str): 原始文本字符串。

    Returns:
        str: 移除特殊标签后的文本字符串。
    """
    # 定义正则表达式模式来匹配 <标签>任何内容</标签> 形式的文本
    # 这里使用了非贪婪匹配 .*? 来确保它只匹配到最近的 </标签>
    # <表情> 和 <动作> 是或的关系，所以用 | 连接
    # re.DOTALL 标志使得 . 能匹配包括换行符在内的所有字符
    pattern = r"<表情>.*?</表情>|<动作>.*?</动作>"

    # 使用 re.sub() 函数将匹配到的模式替换为空字符串
    cleaned_text = re.sub(pattern, "", text, flags=re.DOTALL)

    return cleaned_text

def minimax_text2voice(api_key, group_id, text, seq, voice_id, emotion:str = "happy", config=None):
    """minimax语音转文本"""
    old_text = text
    text = remove_special_tags(text)
    if not REMOVE_FILTER:
        text = prepare_tts_input_with_context(text)
    print("替换后:" + text)

    # 使用配置中的参数，如果没有配置则使用默认值
    speed = float(config.get("speed", 1)) if config else 1
    vol = float(config.get("vol", 2)) if config else 2

    url = f"https://api.minimaxi.com/v1/t2a_v2?GroupId={group_id}"
    data = {
        "model":"speech-2.6-turbo",
        "text":text,
        "stream":False,
        "language_boost":"auto",
        "output_format":"hex",
        "voice_setting":{
            "voice_id": voice_id,
            "speed": speed,
            "vol": vol,
            "pitch":0,
            "english_normalization": False
        },
        "audio_setting":{
            "sample_rate":32000,
            "bitrate":128000,
            "format":"wav"
        }
      }

    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=json.dumps(data))
    parsed_json = json.loads(response.text)
    audio_data = bytes.fromhex(parsed_json['data']['audio'])
    duration = parsed_json["extra_info"]["audio_length"] / 1000
    audio_base64 = base64.b64encode(audio_data).decode("utf-8")
    result = {
        "seq": seq,
        "text": old_text,
        "wav_base64": audio_base64,
        "duration": f"{duration:.2f}"
    }
    print(f"音频时常:{duration}")
    return result





def text2voice(text, seq, config=None):
    """文本转语音函数，使用更安全的内存管理方式"""
    old_text = text
    text = remove_special_tags(text)
    if not REMOVE_FILTER:
        text = prepare_tts_input_with_context(text)
    print("替换后:" + text)

    # 使用配置中的参数，如果没有配置则使用默认值
    if config:
        voice = config.get("voice_id", DEFAULT_VOICE)
        speed = float(config.get("speed", DEFAULT_SPEED))
    else:
        voice = DEFAULT_VOICE
        speed = float(DEFAULT_SPEED)

    response_format = DEFAULT_RESPONSE_FORMAT
    output_file_path = generate_speech(text, voice, response_format, speed)
    duration = get_audio_duration(output_file_path)
    with open(output_file_path, "rb") as f:
        audio_data = f.read()
    audio_base64 = base64.b64encode(audio_data).decode("utf-8")
    result = {
        "seq": seq,
        "text": old_text,
        "wav_base64": audio_base64,
        "duration": f"{duration:.2f}"
    }
    print(f"音频时常:{duration}")
    os.remove(output_file_path)
    return result

@app.post("/test-edge-tts")
async def test_edge_tts(request: Request):
    data = await request.json()
    text = data.get("text", "")
    voice = data.get("voice_id", DEFAULT_VOICE)
    speed = float(data.get("speed", DEFAULT_SPEED))

    response_format = DEFAULT_RESPONSE_FORMAT
    # 直接调用异步版本，避免 asyncio.run() 冲突
    output_file_path = await _generate_audio(text, voice, response_format, speed)
    duration = get_audio_duration(output_file_path)
    with open(output_file_path, "rb") as f:
        audio_data = f.read()
    audio_base64 = base64.b64encode(audio_data).decode("utf-8")
    result = {
        "seq": 1,
        "text": text,
        "wav_base64": audio_base64,
        "duration": f"{duration:.2f}"
    }
    print(f"音频时常:{duration}")
    os.remove(output_file_path)
    return result

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5050)