The pretrained model checkpoints can be reached at https://huggingface.co/SWivid/F5-TTS.

Scripts will automatically pull model checkpoints from Huggingface, by default to `~/.cache/huggingface/hub/`.
