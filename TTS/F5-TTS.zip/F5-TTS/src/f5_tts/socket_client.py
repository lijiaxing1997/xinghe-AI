import socket
import asyncio
import pyaudio
import numpy as np
import logging
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def listen_to_F5TTS(text, server_ip="localhost", server_port=9998):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    await asyncio.get_event_loop().run_in_executor(None, client_socket.connect, (server_ip, int(server_port)))

    start_time = time.time()
    first_chunk_time = None

    async def play_audio_stream():
        nonlocal first_chunk_time
        p = pyaudio.PyAudio()
        stream = p.open(format=pyaudio.paFloat32, channels=1, rate=24000, output=True, frames_per_buffer=2048)

        try:
            while True:
                data = await asyncio.get_event_loop().run_in_executor(None, client_socket.recv, 8192)
                if not data:
                    break
                if data == b"END":
                    logger.info("End of audio received.")
                    break

                audio_array = np.frombuffer(data, dtype=np.float32)
                stream.write(audio_array.tobytes())

                if first_chunk_time is None:
                    first_chunk_time = time.time()

        finally:
            stream.stop_stream()
            stream.close()
            p.terminate()

        logger.info(f"Total time taken: {time.time() - start_time:.4f} seconds")

    try:
        data_to_send = f"{text}".encode("utf-8")
        await asyncio.get_event_loop().run_in_executor(None, client_socket.sendall, data_to_send)
        await play_audio_stream()

    except Exception as e:
        logger.error(f"Error in listen_to_F5TTS: {e}")

    finally:
        client_socket.close()


if __name__ == "__main__":
    text_to_send = """爱国，是一种深沉而真挚的情感，它如同一颗种子，深植在我们每一个人的心中。爱国不仅仅是一句口号，更是一种行动，是我们对这片土地、对这个国家深深的热爱和责任。
爱国，是每当国歌响起时，我们肃立致敬的庄重；是每当国旗飘扬时，我们心中涌动的自豪。它是我们在国家面临困难时，挺身而出的勇气；是我们在国家需要我们时，毫不犹豫地奉献的决心。
爱国，也是我们在日常生活中的点点滴滴。它是我们在公共场合遵守秩序、尊重他人的表现；是我们在面对不公时，敢于发声、勇于斗争的勇气；是我们在看到国家发展、社会进步时，内心的欣慰和自豪。
爱国，更是一种责任。它要求我们关心国家大事，关注社会发展，积极参与到国家的建设中来。它要求我们在享受国家发展成果的同时，也要为国家的未来贡献自己的力量。
总的来说，爱国是一种情感，更是一种行动。它需要我们用实际行动去践行，用真诚的心去感受。让我们都成为有爱国情怀的人，用我们的行动，为这个国家的未来贡献自己的一份力量""".strip()

    asyncio.run(listen_to_F5TTS(text_to_send))
