import socket
import asyncio
import numpy as np
import logging
import time
import wave

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def listen_to_F5TTS_and_save(text, output_filename="output.wav", server_ip="localhost", server_port=9998):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    await asyncio.get_event_loop().run_in_executor(None, client_socket.connect, (server_ip, int(server_port)))

    start_time = time.time()
    all_audio_data = b""

    async def receive_audio_stream():
        nonlocal all_audio_data
        try:
            while True:
                data = await asyncio.get_event_loop().run_in_executor(None, client_socket.recv, 8192)
                if not data:
                    break
                if data == b"END":
                    logger.info("End of audio received.")
                    break

                all_audio_data += data

        except Exception as e:
            logger.error(f"Error receiving audio data: {e}")

    try:
        data_to_send = f"{text}".encode("utf-8")
        await asyncio.get_event_loop().run_in_executor(None, client_socket.sendall, data_to_send)
        await receive_audio_stream()

        # Save the audio data to a WAV file
        audio_array = np.frombuffer(all_audio_data, dtype=np.float32)
        audio_int16 = (audio_array * 32767).astype(np.int16)  # Convert to int16

        with wave.open(output_filename, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)  # 2 bytes for int16
            wf.setframerate(24000)
            wf.writeframes(audio_int16.tobytes())

        logger.info(f"Audio saved to {output_filename}")
        logger.info(f"Total time taken: {time.time() - start_time:.4f} seconds")

    except Exception as e:
        logger.error(f"Error in listen_to_F5TTS_and_save: {e}")

    finally:
        client_socket.close()


if __name__ == "__main__":
    text_to_send = """爱国，是一种深沉而真挚的情感，它如同一颗种子，深植在我们每一个人的心中。""".strip() #add test text.
    output_file = "output_audio.wav"

    asyncio.run(listen_to_F5TTS_and_save(text_to_send, output_file))
