import fitz
import os
from PIL import Image
from paddleocr import PaddleOCR
from fastmcp import FastMCP

mcp = FastMCP("pdf_ocr",debug=True,log_level="DEBUG")

default_params = {
            'use_angle_cls': True,     # 使用角度分类器
            'lang': 'ch',              # 中文识别
            'use_gpu': False,          # 不使用GPU
            'show_log': False,         # 不显示日志
            'det_db_thresh': 0.2,      # 降低检测阈值，增加检测区域
            'det_db_box_thresh': 0.3,  # 降低框阈值
            'det_db_unclip_ratio': 1.8, # 增加unclip比例，扩大检测区域
            'det_model_dir': './model/det',
            'cls_model_dir': './model/cls',
            'rec_model_dir': './model/rec'
        }
ocr = PaddleOCR(**default_params)

def pdf_to_images_pymupdf(pdf_path, output_folder, zoom_factor=3, fmt="png"):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"已创建输出文件夹: {output_folder}")

    if not os.path.exists(pdf_path):
        print(f"错误: PDF文件 '{pdf_path}' 不存在。")
        return

    try:
        doc = fitz.open(pdf_path)
        print(f"成功打开PDF文件: {pdf_path}，共 {doc.page_count} 页。")

        mat = fitz.Matrix(zoom_factor, zoom_factor)

        for page_num in range(doc.page_count):
            page = doc.load_page(page_num)
            pix = page.get_pixmap(matrix=mat, alpha=False)

            # --- 调试信息 ---
            print(f"\n--- 页面 {page_num + 1} 的 Pixmap 信息 ---")
            print(f"  Pixmap 宽度: {pix.width}")
            print(f"  Pixmap 高度: {pix.height}")
            print(f"  Pixmap 颜色空间: {pix.colorspace}")
            print(f"  Pixmap 组件数 (samples): {len(pix.samples)}")
            # 检查是否有非零像素数据，这不能百分百保证图片有内容，但能排除完全空白的pixmap
            if len(pix.samples) > 0 and sum(pix.samples) == 0:
                print("  警告: Pixmap 数据全部为零，可能导致空白图片。")
            elif len(pix.samples) == 0:
                 print("  警告: Pixmap 数据为空！")
            else:
                print("  Pixmap 数据似乎包含内容。")
            # --- 调试信息结束 ---

            output_filename = os.path.join(output_folder, f"page_{page_num + 1}.{fmt}")

            if fmt.lower() == "png":
                pix.save(output_filename)
            elif fmt.lower() == "jpeg" or fmt.lower() == "jpg":
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                img.save(output_filename, "JPEG")
            else:
                print(f"不支持的图片格式: {fmt}。请使用 'png' 或 'jpeg'。")
                continue

            print(f"  保存图片: {output_filename}")

        doc.close()
        print(f"成功将 {pdf_path} 转换为图片，并保存到 {output_folder}")

    except Exception as e:
        print(f"转换失败，发生错误: {e}")
        import traceback
        traceback.print_exc()

def toimages(input_pdf_file):
    output_image_directory = "imgs"

    try:
        from reportlab.pdfgen import canvas
        if not os.path.exists(input_pdf_file):
            print(f"正在创建示例PDF文件: {input_pdf_file}...")
            c = canvas.Canvas(input_pdf_file)
            c.drawString(100, 750, "Hello, this is Page 1 of the PDF (PyMuPDF test).")
            c.showPage()
            c.drawString(100, 750, "This is Page 2 (PyMuPDF test).")
            # 添加一些更复杂的内容，例如一个矩形
            c.rect(200, 600, 100, 50, fill=1) # 填充矩形
            c.setFillColorRGB(1,0,0) # 设置红色
            c.drawString(210, 620, "Red Box!")
            c.save()
            print(f"已成功创建示例PDF文件: {input_pdf_file}")
        else:
            print(f"PDF文件 '{input_pdf_file}' 已存在，跳过创建。")
    except ImportError:
        print("警告: 无法导入 'reportlab'。如果您没有 'example.pdf' 文件，请手动创建它。")
        print("您可以通过 'pip install reportlab' 安装 reportlab 来自动创建示例PDF。")
        exit() # 如果没有 reportlab 且没有手动提供PDF，这里退出
    except Exception as e:
        print(f"创建示例PDF文件失败: {e}")
        print("请确保您有写入当前目录的权限。")
        exit()

    print("\n--- 开始PDF到图片转换 ---")
    # 尝试使用更高的 zoom_factor 和不同的格式
    pdf_to_images_pymupdf(input_pdf_file, output_image_directory, zoom_factor=5, fmt="png")
    print("--- 转换结束 ---")

# toimages("郑思远行政复议申请书2(1).pdf")


def ocr_pdf():
    result_content = ""
    files = [f for f in os.listdir('imgs') if os.path.isfile(os.path.join('imgs', f))]
    files.sort()
    for file in files:
        result = ocr.ocr("./imgs/" + file, cls=True)
        for idx in range(len(result)):
            res = result[idx]
            for line in res:
                result_content += line[-1][0]
    os.system("rm -rf ./imgs/*")
    return result_content

@mcp.tool()
def ocr_pdf_tool(pdf_file:str) -> str:
    """
    ocr识别pdf并且返回pdf内容
    :param pdf_file: pdf文件路径
    :return: 识别结果
    """
    toimages(pdf_file)
    return ocr_pdf()

mcp.run(transport="sse",port=2223)