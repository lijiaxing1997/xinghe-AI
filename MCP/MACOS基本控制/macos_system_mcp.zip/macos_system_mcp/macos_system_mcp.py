from fastmcp import FastMCP
import time
from pynput.keyboard import Controller, Key
import subprocess

mcp = FastMCP("macos_system_mcp",debug=True,log_level="DEBUG")

@mcp.tool()
def launch_app(app_name: str) -> str:
    """启动程序
    :param app_name: 要启动的程序名称
    :return: 执行结果
    """
    keyboard = Controller()
    # 1. 模拟按下 Command + 空格 来激活 Spotlight
    # 确保Command键先按下
    keyboard.press(Key.cmd_l)
    time.sleep(0.1)  # 短暂延迟，确保Command键被系统识别为按下
    keyboard.press(Key.space)
    time.sleep(0.1)  # 短暂延迟
    keyboard.release(Key.space)
    keyboard.release(Key.cmd_l)
    print("模拟 Command + 空格...")

    # 2. 等待 Spotlight 搜索框出现并准备好接受输入
    # 这个延迟非常关键，可能需要根据你的Mac性能和Spotlight的响应速度进行调整
    time.sleep(0.5)

    # 3. 模拟输入应用程序名称
    keyboard.type(app_name)

    # 4. 模拟按下回车键来启动第一个搜索结果
    time.sleep(0.5)  # 稍微延迟，确保输入完成
    keyboard.press(Key.enter)
    keyboard.release(Key.enter)
    time.sleep(0.2)
    keyboard.press(Key.enter)
    keyboard.release(Key.enter)

    return f"'{app_name}' 应用已尝试启动。"

@mcp.tool()
def close_app(app_name: str) -> str:
    """关闭程序
    :param app_name: 要关闭的应用名称
    :return: 关闭结果
    """
    script = f'tell application "{app_name}" to quit'
    try:
        subprocess.run(["osascript", "-e", script], check=True)
        return f"已发送正常退出命令给应用程序: {app_name}"
    except subprocess.CalledProcessError as e:
        return f"无法正常退出应用程序 {app_name}。可能是应用程序未运行或无响应。错误: {e}"
    except FileNotFoundError:
        return "错误: 'osascript' 命令未找到。请确保在 macOS 环境下运行。"

@mcp.tool()
def set_volume(volume: int) -> str:
    """
    设置macos的音量
    :param volume: 0 到 100 之间的整数。
    :return: 设置结果
    """
    if not 0 <= volume <= 100:
        return "错误：音量必须在 0 到 100 之间。"


    script = f"set volume output volume {volume}"
    subprocess.run(["osascript", "-e", script])
    return "执行成功"

@mcp.tool()
def full_screen(placeholder:str = "") -> str:
    """
    模拟按下 Control + Command + F 组合键。
    这个组合键在 macOS 中通常用于切换全屏模式。
    :param placeholder: 占位可不填
    :return: 返回结果
    """
    keyboard = Controller()

    # 按下 Control 键
    keyboard.press(Key.ctrl)
    # 按下 Command 键
    keyboard.press(Key.cmd)
    # 按下 F 键
    keyboard.press('f')

    # 释放所有按下的键，顺序与按下相反
    keyboard.release('f')
    keyboard.release(Key.cmd)
    keyboard.release(Key.ctrl)

    return "已模拟按下 Control + Command + F，执行了全屏"

@mcp.tool()
def swipe_space(direction:str) -> str:
    """
    macos上进行屏幕切换的工具
    :param direction: 有两个参数left、right
    :return:切换结果
    """
    if direction == "left":
        script = 'tell application "System Events" to key code 123 using control down'  # 123 是左箭头键的 key code
        subprocess.run(["osascript", "-e", script])
        return "已通过 AppleScript 向左切换 Space。"
    elif direction == "right":
        script = 'tell application "System Events" to key code 124 using control down'  # 124 是右箭头键的 key code
        subprocess.run(["osascript", "-e", script])
        return "已通过 AppleScript 向右切换 Space。"
    else:
        return "错误：direction 参数必须是 'left' 或 'right'。"

@mcp.tool()
def lock_screen(placeholder:str = ""):
    """
    执行锁屏
    :param: placeholder: 占位变量可不填
    :return: 锁屏结果
    """
    script = 'tell application "System Events" to keystroke "q" using {command down, control down}'
    subprocess.run(["osascript", "-e", script])
    return "已锁屏。"

@mcp.tool()
def alert_dialog(message: str) -> str:
    """
    弹窗提示用户
    :param message: 弹窗的内容
    :return: 显示结果
    """
    applescript = f'display dialog "{message}" with title "提醒" buttons {{"好"}}'
    subprocess.run(["osascript", "-e", applescript])
    return "已显示弹框。"


mcp.run(transport="sse",port=1234)