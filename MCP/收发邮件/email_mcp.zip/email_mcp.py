import imaplib
import smtplib
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import decode_header
from email.utils import parsedate_to_datetime
import configparser
import os
from typing import List, Dict
from fastmcp import FastMCP

# 初始化FastMCP
mcp = FastMCP("email_mcp", debug=True, log_level="DEBUG")

# 读取配置文件
config = configparser.ConfigParser()
config_path = os.path.join(os.path.dirname(__file__), 'config.ini')
config.read(config_path, encoding='utf-8')

def get_config(section: str, key: str) -> str:
    """获取配置项"""
    return config.get(section, key)

def decode_str(s):
    """解码邮件主题或发件人"""
    if s is None:
        return ""
    
    value, charset = decode_header(s)[0]
    if charset:
        try:
            value = value.decode(charset)
        except:
            try:
                value = value.decode('utf-8')
            except:
                value = value.decode('gbk', errors='ignore')
    elif isinstance(value, bytes):
        try:
            value = value.decode('utf-8')
        except:
            try:
                value = value.decode('gbk', errors='ignore')
            except:
                value = str(value)
    return str(value)

def get_email_body(msg):
    """提取邮件正文"""
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get("Content-Disposition"))
            
            # 跳过附件
            if "attachment" in content_disposition:
                continue
            
            # 获取文本内容
            if content_type == "text/plain":
                try:
                    payload = part.get_payload(decode=True)
                    charset = part.get_content_charset() or 'utf-8'
                    body = payload.decode(charset, errors='ignore')
                    break
                except:
                    continue
            elif content_type == "text/html" and not body:
                try:
                    payload = part.get_payload(decode=True)
                    charset = part.get_content_charset() or 'utf-8'
                    body = payload.decode(charset, errors='ignore')
                except:
                    continue
    else:
        try:
            payload = msg.get_payload(decode=True)
            charset = msg.get_content_charset() or 'utf-8'
            body = payload.decode(charset, errors='ignore')
        except:
            body = str(msg.get_payload())
    
    return body.strip()

@mcp.tool()
def fetch_unread_emails(max_count: int = 10) -> str:
    """
    获取未读邮件列表
    
    :param max_count: 最多获取的未读邮件数量，默认10封
    :return: 未读邮件的详细信息（JSON格式字符串）
    """
    try:
        # 连接到IMAP服务器
        imap_server = get_config('IMAP', 'server')
        imap_port = int(get_config('IMAP', 'port'))
        email_account = get_config('ACCOUNT', 'email')
        email_password = get_config('ACCOUNT', 'password')
        
        # 使用SSL连接
        mail = imaplib.IMAP4_SSL(imap_server, imap_port)
        mail.login(email_account, email_password)

        # 发送客户端ID信息（126/163等国内邮箱要求）
        try:
            imap_id = ("name", "EmailMCP", "version", "1.0", "vendor", "FastMCP")
            typ, data = mail.xatom('ID', '("' + '" "'.join(imap_id) + '")')
            print(f'ID command result - typ: {typ}, data: {data}')
        except Exception as e:
            print(f'ID command failed (may not be required): {e}')

        # 选择收件箱
        result, message = mail.select('INBOX')
        if result != 'OK':
            return f"选择收件箱失败: {message}"
        print(f'Selected INBOX - result: {result}, message: {message}')
        
        # 搜索未读邮件
        status, messages = mail.search(None, 'UNSEEN')
        
        if status != 'OK':
            return "获取未读邮件失败"
        
        email_ids = messages[0].split()
        
        if not email_ids:
            mail.logout()
            return "没有未读邮件"
        
        # 限制获取数量
        email_ids = email_ids[-max_count:]
        
        unread_emails = []
        
        for email_id in email_ids:
            # 获取邮件
            status, msg_data = mail.fetch(email_id, '(RFC822)')
            
            if status != 'OK':
                continue
            
            # 解析邮件
            raw_email = msg_data[0][1]
            msg = email.message_from_bytes(raw_email)
            
            # 提取邮件信息
            subject = decode_str(msg.get('Subject', ''))
            from_addr = decode_str(msg.get('From', ''))
            date_str = msg.get('Date', '')
            
            # 解析日期
            try:
                date_obj = parsedate_to_datetime(date_str)
                formatted_date = date_obj.strftime('%Y-%m-%d %H:%M:%S')
            except:
                formatted_date = date_str
            
            # 获取邮件正文
            body = get_email_body(msg)
            
            # 限制正文长度，避免过长
            if len(body) > 1000:
                body = body[:1000] + "...(内容过长，已截断)"
            
            email_info = {
                'id': email_id.decode(),
                'subject': subject,
                'from': from_addr,
                'date': formatted_date,
                'body': body
            }
            
            unread_emails.append(email_info)
        
        mail.logout()
        
        # 格式化输出
        result = f"共有 {len(unread_emails)} 封未读邮件：\n\n"
        for idx, email_info in enumerate(unread_emails, 1):
            result += f"【邮件 {idx}】\n"
            result += f"主题: {email_info['subject']}\n"
            result += f"发件人: {email_info['from']}\n"
            result += f"时间: {email_info['date']}\n"
            result += f"内容:\n{email_info['body']}\n"
            result += "-" * 50 + "\n\n"
        
        return result
        
    except Exception as e:
        return f"获取未读邮件时发生错误: {str(e)}"

@mcp.tool()
def send_email(to_addr: str, subject: str, body: str, cc: str = "") -> str:
    """
    发送邮件
    
    :param to_addr: 收件人邮箱地址
    :param subject: 邮件主题
    :param body: 邮件正文
    :param cc: 抄送地址（可选，多个地址用逗号分隔）
    :return: 发送结果
    """
    try:
        # 获取配置
        smtp_server = get_config('SMTP', 'server')
        smtp_port = int(get_config('SMTP', 'port'))
        email_account = get_config('ACCOUNT', 'email')
        email_password = get_config('ACCOUNT', 'password')
        
        # 创建邮件对象
        msg = MIMEMultipart()
        msg['From'] = email_account
        msg['To'] = to_addr
        msg['Subject'] = subject
        
        # 处理抄送
        if cc:
            msg['Cc'] = cc
        
        # 添加邮件正文
        msg.attach(MIMEText(body, 'plain', 'utf-8'))
        
        # 连接SMTP服务器
        server = smtplib.SMTP_SSL(smtp_server, smtp_port)
        server.login(email_account, email_password)
        
        # 发送邮件
        recipients = [to_addr]
        if cc:
            recipients.extend([addr.strip() for addr in cc.split(',')])
        
        server.sendmail(email_account, recipients, msg.as_string())
        server.quit()
        
        return f"邮件发送成功！\n收件人: {to_addr}\n主题: {subject}"
        
    except Exception as e:
        return f"发送邮件时发生错误: {str(e)}"

# 启动MCP服务器
if __name__ == "__main__":
    mcp.run(transport="sse", port=3456, host="0.0.0.0")

