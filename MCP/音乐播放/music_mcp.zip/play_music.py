import os.path
import requests
import re
import json
import pygame
import threading
import queue
import random

# --- 全局变量和队列 ---
# No longer using music_queue as a direct queue, but keeping for conceptual clarity.
# The play list is directly managed.
current_play_list = []  # Current list of song filenames (e.g., ["song1.mp3", "song2.mp3"])
current_play_mode = "single"
current_song_index = -1  # Current song index in current_play_list

# Control events for the playback thread
is_playing = threading.Event()  # Set when music should be playing (active or paused)
is_paused = threading.Event()  # Set when music is explicitly paused by user
should_load_new_song = threading.Event()  # Set when the thread needs to load a new song

playback_thread = None


# --- 播放线程函数 ---
def music_playback_thread():
    global current_song_index, current_play_list, current_play_mode

    # Ensure mixer is initialized for this thread when it starts
    if not pygame.mixer.get_init():
        pygame.mixer.init()

    while True:
        # Check if we need to load a new song (e.g., next/prev, or initial play_musics_local)
        if should_load_new_song.is_set():
            pygame.mixer.music.stop()  # Stop any currently playing music
            should_load_new_song.clear()  # Clear the flag once processed

            if not current_play_list:
                print("播放列表为空，无法加载新歌曲。")
                is_playing.clear()  # No music to play, so clear playing state
                is_paused.clear()
                continue  # Go back to the top of the loop

            if not (0 <= current_song_index < len(current_play_list)):
                current_song_index = 0  # Reset index if invalid
                if not current_play_list:
                    print("播放列表为空或索引无效。")
                    is_playing.clear()
                    is_paused.clear()
                    continue

            song_file_name = current_play_list[current_song_index]
            song_to_play_path = os.path.join("music_file", song_file_name)

            if not os.path.exists(song_to_play_path):
                print(f"错误: 歌曲文件 '{song_file_name}' 未找到，跳过。")
                if current_play_mode in ["list", "random"]:
                    current_song_index = (current_song_index + 1) % len(current_play_list)
                    should_load_new_song.set()  # Signal to load the next song
                else:
                    is_playing.clear()  # If single mode and file not found, stop
                    is_paused.clear()
                continue  # Go back to the top of the loop

            try:
                pygame.mixer.music.load(song_to_play_path)
                # Only play if not paused. If paused, it will be unpaused later.
                if not is_paused.is_set():
                    pygame.mixer.music.play()
                print(f"正在播放 (后台): {song_file_name}")
                is_playing.set()  # Confirm that playback is active (or ready to be)

            except pygame.error as e:
                print(f"Pygame加载/播放错误: {e}. 可能音频文件损坏或格式不支持。跳过。")
                is_playing.clear()
                is_paused.clear()
                pygame.mixer.music.stop()
                # Try to advance if in list/random mode
                if current_play_mode in ["list", "random"] and current_play_list:
                    current_song_index = (current_song_index + 1) % len(current_play_list)
                    should_load_new_song.set()  # Signal to load the next song
                continue

        # --- Playback Management ---
        # If music is supposed to be playing (is_playing is set)
        if is_playing.is_set():
            # If currently playing (get_busy) and not paused
            if pygame.mixer.music.get_busy() and not is_paused.is_set():
                pygame.time.Clock().tick(10)  # Keep ticking
            # If not busy (song finished) AND not paused AND is_playing is still desired
            elif not pygame.mixer.music.get_busy() and not is_paused.is_set():
                # Song has finished naturally, advance to next based on mode
                if current_play_list:  # Only advance if there's a list
                    if current_play_mode == "single":
                        # For single, just reload and play the same song
                        should_load_new_song.set()
                    elif current_play_mode == "list":
                        current_song_index = (current_song_index + 1) % len(current_play_list)
                        should_load_new_song.set()
                    elif current_play_mode == "random":
                        current_song_index = random.randint(0, len(current_play_list) - 1)
                        should_load_new_song.set()
                else:  # No list, so stop playing
                    is_playing.clear()
                    is_paused.clear()
                    pygame.mixer.music.stop()
            # If paused (is_paused is set), just tick and wait for unpause signal
            elif is_paused.is_set():
                pygame.time.Clock().tick(10)  # Keep ticking to prevent high CPU use
                # The thread will effectively wait here until unpause_music clears is_paused
                # and then play() is called directly or should_load_new_song is set.
                # In our design, unpause_music() directly calls unpause().
        else:  # If is_playing is not set (e.g., after stop_music), just idle
            pygame.time.Clock().tick(100)  # Sleep longer to save CPU when idle
            # We don't block with is_playing.wait() here anymore to allow immediate reaction
            # to should_load_new_song from external calls.

        # Short sleep to prevent busy-waiting when no active playback
        # This is already handled by pygame.time.Clock().tick(10) or (100)
        # threading.Event.wait() is only used in is_paused context now.


from fastmcp import FastMCP

mcp = FastMCP("play_music", debug=True, log_level="DEBUG")

# Ensure music_file folder exists
if not os.path.exists("music_file"):
    os.makedirs("music_file")

# Initialize mixer once at the program start for tool functions, but also in thread for its context
pygame.mixer.init()



@mcp.tool()
def pause_music(placeholder: str = ""):
    """暂停当前播放的音乐。
    :param placeholder: 占位符可不填
    :return: 暂停结果
    """
    global is_paused, is_playing
    if pygame.mixer.music.get_busy():
        pygame.mixer.music.pause()
        is_paused.set()  # Set paused state
        # No need to clear is_playing here, as the thread will check is_paused
        return "音乐已暂停"
    elif is_paused.is_set():
        return "音乐已处于暂停状态"
    else:
        return "音乐未在播放中，无法暂停"


@mcp.tool()
def unpause_music(placeholder: str = ""):
    """恢复暂停的音乐。
    :param placeholder: 占位符可不填
    :return: 恢复结果
    """
    global is_paused, is_playing
    # Check if music is indeed paused (not busy but position not -1, AND is_paused is set)
    if not pygame.mixer.music.get_busy() and pygame.mixer.music.get_pos() != -1 and is_paused.is_set():
        pygame.mixer.music.unpause()
        is_paused.clear()  # Clear paused state
        is_playing.set()  # Ensure playing state is set
        return "音乐已恢复"
    elif pygame.mixer.music.get_busy() and not is_paused.is_set():
        return "音乐正在播放中，无需恢复"
    else:
        return "音乐未在暂停中，无法恢复"


@mcp.tool()
def stop_music(placeholder: str = ""):
    """停止音乐播放并清理资源。
    :param placeholder: 占位符可不填
    :return: 停止结果
    """
    global is_playing, is_paused, current_song_index, should_load_new_song

    pygame.mixer.music.stop()
    is_playing.clear()  # Indicate no music should be playing
    is_paused.clear()  # Clear paused state
    should_load_new_song.clear()  # Clear any pending load requests
    current_song_index = -1  # Reset index

    # We keep the mixer initialized to allow quick restarts
    if not pygame.mixer.get_init():
        pygame.mixer.init()

    print("音乐已停止，Pygame Mixer状态保持。")
    return "音乐已停止，程序准备好接收新的播放指令。"


@mcp.tool()
def play_musics_local(song_name: str = "", play_mode: str = "single") -> str:
    """播放本地音乐
    :param song_name: 要播放的音乐名称,可以留空，留空表示加载进来的歌曲列表为本地文件夹中的所有音乐。
    :param play_mode: 播放模式，可选single（单曲循环），list（列表循环），random（随机播放）
    :return: 播放结果
    """
    global current_play_list, current_play_mode, current_song_index, playback_thread, is_playing, is_paused, should_load_new_song

    # Ensure music_file folder exists
    if not os.path.exists("music_file"):
        os.makedirs("music_file")
        return "本地文件夹中没有音乐文件，已创建文件夹 'music_file'。"

    music_files = [f for f in os.listdir("music_file") if f.endswith(".mp3")]
    if not music_files:
        return "本地文件夹中没有音乐文件"

    play_list_temp = []
    if not song_name:
        play_list_temp = music_files
    else:
        for music_file in music_files:
            if song_name.lower() in music_file.lower():
                play_list_temp.append(music_file)

    if not play_list_temp:
        return f"未找到匹配 '{song_name}' 的本地音乐文件"

    current_play_list = play_list_temp
    current_play_mode = play_mode

    # Set initial playback index
    if play_mode == "random":
        current_song_index = random.randint(0, len(current_play_list) - 1)
    else:
        if song_name:
            try:
                current_song_index = next(i for i, f in enumerate(current_play_list) if song_name.lower() in f.lower())
            except StopIteration:
                current_song_index = 0
        else:
            current_song_index = 0

    # Ensure the background playback thread is running
    if playback_thread is None or not playback_thread.is_alive():
        playback_thread = threading.Thread(target=music_playback_thread, daemon=True)
        playback_thread.start()
        print("后台播放线程已启动。")

    # Signal the thread to load and play the new song
    pygame.mixer.music.stop()  # Stop any current playback from previous session
    is_paused.clear()  # Clear paused state
    is_playing.set()  # Indicate that music should be playing
    should_load_new_song.set()  # Tell the thread to load the song at current_song_index

    return f"已加载 {len(current_play_list)} 首音乐到播放列表。当前播放模式：{play_mode}。即将播放：{current_play_list[current_song_index]}"


@mcp.tool()
def next_song(placeholder: str = "") -> str:
    """播放播放列表中的下一首歌曲。
    :param placeholder: 占位符可不填
    :return: 播放结果
    """
    global current_song_index, current_play_list, is_playing, is_paused, current_play_mode, should_load_new_song

    if not current_play_list:
        return "播放列表为空，无法播放下一首。"

    # Ensure playback state is active
    if not is_playing.is_set():
        is_playing.set()  # Set is_playing if it wasn't already (e.g., after stop)
    if is_paused.is_set():
        is_paused.clear()  # Clear paused state

    # If in single loop mode, switch to list mode when next_song is called
    if current_play_mode == "single":
        current_play_mode = "list"
        print("已从单曲循环模式切换到列表循环模式。")

    # Calculate next song's index based on current play mode
    if current_play_mode == "list":
        current_song_index = (current_song_index + 1) % len(current_play_list)
    elif current_play_mode == "random":
        current_song_index = random.randint(0, len(current_play_list) - 1)

    # Signal the playback thread to load the new song
    should_load_new_song.set()

    return f"正在播放下一首: {current_play_list[current_song_index]}"


@mcp.tool()
def previous_song(placeholder: str = "") -> str:
    """播放播放列表中的上一首歌曲。
    :param placeholder: 占位符可不填
    :return: 播放结果
    """
    global current_song_index, current_play_list, is_playing, is_paused, current_play_mode, should_load_new_song

    if not current_play_list:
        return "播放列表为空，无法播放上一首。"

    # Ensure playback state is active
    if not is_playing.is_set():
        is_playing.set()  # Set is_playing if it wasn't already
    if is_paused.is_set():
        is_paused.clear()  # Clear paused state

    # If in single loop mode, switch to list mode when previous_song is called
    if current_play_mode == "single":
        current_play_mode = "list"
        print("已从单曲循环模式切换到列表循环模式。")

    # Calculate previous song's index based on current play mode
    if current_play_mode == "list":
        current_song_index = (current_song_index - 1 + len(current_play_list)) % len(current_play_list)
    elif current_play_mode == "random":
        current_song_index = random.randint(0, len(current_play_list) - 1)

    # Signal the playback thread to load the new song
    should_load_new_song.set()

    return f"正在播放上一首: {current_play_list[current_song_index]}"


@mcp.tool()
def get_playlist(placeholder: str = "") -> str:
    """获取当前播放列表队列。
    :param placeholder: 占位符可不填
    :return: 当前播放列表中的歌曲名称，如果列表为空则返回提示信息。
    """
    global current_play_list, current_song_index

    if not current_play_list:
        return "播放列表当前为空。"

    response_lines = ["当前播放列表中的歌曲："]
    for i, song_name in enumerate(current_play_list):
        prefix = "-> " if i == current_song_index else "   "  # Indicate current song
        response_lines.append(f"{prefix}{i + 1}. {song_name}")

    return "\n".join(response_lines)


# --- FastMCP 运行 ---
# Start the playback thread as soon as the script runs
playback_thread = threading.Thread(target=music_playback_thread, daemon=True)
playback_thread.start()
print("后台播放线程已在脚本启动时启动。")

mcp.run(transport="sse", port=4567)